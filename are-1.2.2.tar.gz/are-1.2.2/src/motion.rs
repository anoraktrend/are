// motion.rs – cursor-movement routines
// Mirrors src/motion.c exactly (bottom, top, nextline, prevline, left, right,
// find_pos, up, down, adv_word, prev_word, move_rel, eol, bol, adv_line,
// next_page, prev_page, goto_line).
//
// All public functions take `&mut Buffer` to match the calling convention used
// in main.rs and format.rs.

use crate::editor_state::Buffer;
use crate::ui::{scanline, COLS};

// ────────────────────────────────────────────────────────────────────────────
// Internal character-width helper (mirrors C `len_char`)
// ────────────────────────────────────────────────────────────────────────────

fn len_char(scr_pos: i32, ch: char) -> i32 {
    if ch == '\t' {
        8 - (scr_pos % 8)
    } else if (ch as u32) < 32 || ch == '\x7f' {
        2
    } else {
        1
    }
}

// ────────────────────────────────────────────────────────────────────────────
// bottom / top
// ────────────────────────────────────────────────────────────────────────────

/// Move cursor to the bottom of the file (mirrors C `bottom()`).
pub fn bottom(buff: &mut Buffer) {
    let pos = buff.position;
    if pos > 1 {
        adv_line(buff);
    }
    let num_lines = {
        let mut count = 0i32;
        let mut current_idx = buff.curr_line_idx;
        while current_idx < buff.lines.len() {
            if current_idx + 1 >= buff.lines.len() {
                break;
            }
            count += 1;
            current_idx += 1;
        }
        count
    };
    move_rel(buff, "d", num_lines);
}

/// Move cursor to the top of the file (mirrors C `top()`).
pub fn top(buff: &mut Buffer) {
    let num_lines = {
        let mut count = 0i32;
        let mut current_idx = buff.curr_line_idx;
        while current_idx > 0 {
            count += 1;
            current_idx -= 1;
        }
        count
    };
    move_rel(buff, "u", num_lines);
}

// ────────────────────────────────────────────────────────────────────────────
// nextline / prevline
// ────────────────────────────────────────────────────────────────────────────

/// Move to the first character of the next line (mirrors C `nextline()`).
pub fn nextline(buff: &mut Buffer) {
    if buff.curr_line_idx + 1 < buff.lines.len() {
        let cols = COLS();
        let vert_len = buff.lines[buff.curr_line_idx].vert_len - (buff.scr_pos / cols);

        buff.curr_line_idx += 1;
        buff.position = 1;
        buff.abs_pos = 0;
        buff.scr_pos = 0;
        buff.scr_horz = 0;

        let new_vert = buff.scr_vert.saturating_add(vert_len);
        buff.scr_vert = new_vert.min(buff.last_line);
    }
}

/// Move to the last character of the previous line (mirrors C `prevline()`).
pub fn prevline(buff: &mut Buffer) {
    if buff.curr_line_idx > 0 {
        let cols = COLS();
        let prev_vert = buff.lines[buff.curr_line_idx - 1].vert_len;
        let p = prev_vert + (buff.scr_pos / cols);

        buff.curr_line_idx -= 1;
        buff.position = 1;
        buff.scr_pos = 0;
        buff.scr_vert = buff.scr_vert.saturating_sub(p);

        // Advance to end of the (now-current) previous line.
        let ll = buff.lines[buff.curr_line_idx].line_length;
        while buff.position < ll {
            buff.position = buff.position.saturating_add(1);
        }
        let scr_p = scanline(&buff.lines[buff.curr_line_idx], buff.position);
        buff.abs_pos = scr_p;
        buff.scr_pos = scr_p;
    }
}

// ────────────────────────────────────────────────────────────────────────────
// find_pos (mirrors C `find_pos()`)
// ────────────────────────────────────────────────────────────────────────────

/// Restore the cursor to the same column on the new current line.
/// Called after up()/down() to preserve horizontal position.
pub fn find_pos(buff: &mut Buffer) {
    let target = buff.abs_pos;
    let mut scr_horz = 0i32;
    let mut pos = 1i32;

    if buff.curr_line_idx >= buff.lines.len() {
        return;
    }

    let line = &buff.lines[buff.curr_line_idx];
    let ll = line.line_length;
    let chars: Vec<char> = line.line.chars().collect();

    while scr_horz < target && pos < ll {
        let ch = chars.get((pos - 1) as usize).copied().unwrap_or('\0');
        scr_horz = scr_horz.saturating_add(len_char(scr_horz, ch));
        pos = pos.saturating_add(1);
    }

    buff.scr_horz = scr_horz % COLS();
    buff.scr_pos = scr_horz;
    buff.position = pos;
}

// ────────────────────────────────────────────────────────────────────────────
// left / right
// ────────────────────────────────────────────────────────────────────────────

/// Move cursor one character left (mirrors C `left()`).
/// Returns `true` if the cursor moved.
pub fn left(buff: &mut Buffer, _disp: bool) -> bool {
    let pos = buff.position;
    let scr_pos = buff.scr_pos;

    if pos != 1 {
        let ch = {
            if buff.curr_line_idx >= buff.lines.len() {
                '\0'
            } else {
                let line = &buff.lines[buff.curr_line_idx];
                let chars: Vec<char> = line.line.chars().collect();
                chars.get((pos - 2) as usize).copied().unwrap_or('\0')
            }
        };

        buff.position -= 1;
        let new_scr = if ch == '\t' {
            if buff.curr_line_idx >= buff.lines.len() {
                0
            } else {
                scanline(&buff.lines[buff.curr_line_idx], buff.position)
            }
        } else {
            scr_pos - len_char(scr_pos, ch)
        };
        buff.abs_pos = new_scr;
        buff.scr_pos = new_scr;
        buff.scr_horz = new_scr % COLS();
        true
    } else {
        let has_prev = buff.curr_line_idx > 0;
        if has_prev {
            prevline(buff);
            buff.scr_horz = buff.scr_pos % COLS();
            buff.absolute_lin -= 1;
            true
        } else {
            false
        }
    }
}

/// Move cursor one character right (mirrors C `right()`).
/// Returns `true` if the cursor moved.
pub fn right(buff: &mut Buffer, _disp: bool) -> bool {
    let pos = buff.position;
    let ll = if buff.curr_line_idx < buff.lines.len() {
        buff.lines[buff.curr_line_idx].line_length
    } else {
        1
    };

    if pos < ll {
        let ch = {
            if buff.curr_line_idx >= buff.lines.len() {
                '\0'
            } else {
                let line = &buff.lines[buff.curr_line_idx];
                let chars: Vec<char> = line.line.chars().collect();
                chars.get((pos - 1) as usize).copied().unwrap_or('\0')
            }
        };

        let r = buff.scr_pos.saturating_add(len_char(buff.scr_pos, ch));
        buff.position = buff.position.saturating_add(1);
        buff.abs_pos = r;
        buff.scr_pos = r;
        buff.scr_horz = r % COLS();
        true
    } else {
        let has_next = buff.curr_line_idx + 1 < buff.lines.len();
        if has_next {
            nextline(buff);
            buff.position = 1;
            buff.abs_pos = 0;
            buff.scr_pos = 0;
            buff.absolute_lin += 1;
            true
        } else {
            false
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
// up / down
// ────────────────────────────────────────────────────────────────────────────

/// Move cursor up one line (mirrors C `up()`).
pub fn up(buff: &mut Buffer) {
    if buff.curr_line_idx == 0 {
        return;
    }

    let tscr_pos = buff.abs_pos;

    // Move to previous line
    buff.curr_line_idx -= 1;
    buff.position = 1;
    buff.scr_horz = 0;
    buff.scr_pos = 0;
    buff.abs_pos = tscr_pos;

    // Find the position on the new line that matches our horizontal target
    find_pos(buff);
    buff.scr_pos = buff.scr_horz;

    // Update vertical position
    if buff.scr_vert > 0 {
        // Still room on screen, just move up
        buff.scr_vert = buff.scr_vert.saturating_sub(1);
    } else {
        // At top of screen, scroll the window up
        buff.window_top = buff.window_top.saturating_sub(1);
    }

    buff.absolute_lin = buff.absolute_lin.saturating_sub(1);
}

/// Move cursor down one line (mirrors C `down()`).
pub fn down(buff: &mut Buffer) {
    if buff.curr_line_idx + 1 >= buff.lines.len() {
        return;
    }

    let tscr_pos = buff.abs_pos;

    // Move to next line
    buff.curr_line_idx += 1;
    buff.position = 1;
    buff.scr_horz = 0;
    buff.scr_pos = 0;
    buff.abs_pos = tscr_pos;

    // Find the position on the new line that matches our horizontal target
    find_pos(buff);
    buff.scr_pos = buff.scr_horz;

    // Update vertical position
    if buff.scr_vert < buff.last_line {
        // Still room on screen, just move down
        buff.scr_vert = buff.scr_vert.saturating_add(1);
    } else {
        // At bottom of screen, scroll the window
        buff.window_top = buff.window_top.saturating_add(1);
    }

    buff.absolute_lin = buff.absolute_lin.saturating_add(1);
}

// ────────────────────────────────────────────────────────────────────────────
// Public aliases used by main.rs and format.rs
// ────────────────────────────────────────────────────────────────────────────

/// Alias for `left(buff, true)` – used by main.rs key handling.
pub fn move_left(buff: &mut Buffer) {
    left(buff, true);
}

/// Alias for `right(buff, true)` – used by main.rs key handling.
pub fn move_right(buff: &mut Buffer) {
    right(buff, true);
}

/// Alias for `up(buff)` – used by main.rs key handling.
pub fn move_up(buff: &mut Buffer) {
    up(buff);
}

/// Alias for `down(buff)` – used by main.rs key handling.
pub fn move_down(buff: &mut Buffer) {
    down(buff);
}

// ────────────────────────────────────────────────────────────────────────────
// goto_line (mirrors C `goto_line()`)
// ────────────────────────────────────────────────────────────────────────────

/// Move cursor to absolute line number `n` (1-based).
pub fn goto_line(buff: &mut Buffer, n: i32) {
    // Go to top first.
    top(buff);
    // Then advance n-1 lines.
    for _ in 1..n {
        if buff.curr_line_idx + 1 >= buff.lines.len() {
            break;
        }
        adv_line(buff);
    }
}

// ────────────────────────────────────────────────────────────────────────────
// adv_word / prev_word
// ────────────────────────────────────────────────────────────────────────────

fn curr_char(buff: &Buffer) -> char {
    let pos = buff.position;
    if buff.curr_line_idx >= buff.lines.len() {
        return '\0';
    }
    let chars: Vec<char> = buff.lines[buff.curr_line_idx].line.chars().collect();
    chars.get((pos - 1) as usize).copied().unwrap_or('\0')
}

fn prev_char(buff: &Buffer) -> char {
    let pos = buff.position;
    if pos < 2 || buff.curr_line_idx >= buff.lines.len() {
        return '\0';
    }
    let chars: Vec<char> = buff.lines[buff.curr_line_idx].line.chars().collect();
    chars.get((pos - 2) as usize).copied().unwrap_or('\0')
}

fn at_end(buff: &Buffer) -> bool {
    let ll = if buff.curr_line_idx < buff.lines.len() {
        buff.lines[buff.curr_line_idx].line_length
    } else {
        1
    };
    buff.position >= ll
}

fn at_start(buff: &Buffer) -> bool {
    buff.position == 1
}

fn is_word_sep(ch: char) -> bool {
    ch == ' ' || ch == '\t'
}

/// Advance to the next word (mirrors C `adv_word()`).
pub fn adv_word(buff: &mut Buffer) {
    if at_end(buff) {
        right(buff, true);
        return;
    }
    while !at_end(buff) && !is_word_sep(curr_char(buff)) {
        right(buff, true);
    }
    while !at_end(buff) && is_word_sep(curr_char(buff)) {
        right(buff, true);
    }
}

/// Move to the start of the previous word (mirrors C `prev_word()`).
pub fn prev_word(buff: &mut Buffer) {
    if at_start(buff) {
        left(buff, true);
        return;
    }
    if !at_start(buff) && is_word_sep(prev_char(buff)) {
        while !at_start(buff) && !is_word_sep(curr_char(buff)) {
            left(buff, true);
        }
    }
    while !at_start(buff) && is_word_sep(curr_char(buff)) {
        left(buff, true);
    }
    while !at_start(buff) && !is_word_sep(curr_char(buff)) {
        left(buff, true);
    }
    if !at_start(buff) && is_word_sep(curr_char(buff)) {
        right(buff, true);
    }
}

// ────────────────────────────────────────────────────────────────────────────
// eol / bol / adv_line
// ────────────────────────────────────────────────────────────────────────────

/// Move to end of current line (mirrors C `eol()`).
pub fn eol(buff: &mut Buffer) {
    let ll = if buff.curr_line_idx < buff.lines.len() {
        buff.lines[buff.curr_line_idx].line_length
    } else {
        1
    };
    let pos = buff.position;

    if pos == ll {
        let has_next = buff.curr_line_idx + 1 < buff.lines.len();
        if has_next {
            right(buff, true);
        }
    }

    let ll2 = if buff.curr_line_idx < buff.lines.len() {
        buff.lines[buff.curr_line_idx].line_length
    } else {
        1
    };
    buff.position = ll2;
    let scr_p = if buff.curr_line_idx < buff.lines.len() {
        scanline(&buff.lines[buff.curr_line_idx], buff.position)
    } else {
        0
    };
    buff.abs_pos = scr_p;
    buff.scr_pos = scr_p;
    buff.scr_horz = scr_p % COLS();
    let delta = (scr_p / COLS()).min(buff.last_line - buff.scr_vert);
    buff.scr_vert = buff.scr_vert.saturating_add(delta);
}

/// Move to beginning of current line (mirrors C `bol()`).
pub fn bol(buff: &mut Buffer) {
    let pos = buff.position;
    let has_prev = buff.curr_line_idx > 0;

    if pos != 1 {
        let delta = buff.scr_pos / COLS();
        buff.position = 1;
        buff.scr_horz = 0;
        buff.scr_pos = 0;
        buff.abs_pos = 0;
        buff.scr_vert = buff.scr_vert.saturating_sub(delta);
    } else if has_prev {
        buff.abs_pos = 0;
        up(buff);
    }
}

/// Advance to the beginning of the next line (mirrors C `adv_line()`).
pub fn adv_line(buff: &mut Buffer) {
    buff.abs_pos = 0;
    let pos = buff.position;
    if pos == 1 {
        down(buff);
    } else {
        let ll = if buff.curr_line_idx < buff.lines.len() {
            buff.lines[buff.curr_line_idx].line_length
        } else {
            1
        };
        if pos < ll {
            eol(buff);
        }
        right(buff, true);
    }
}

// ────────────────────────────────────────────────────────────────────────────
// move_rel (mirrors C `move_rel(direction, lines)`)
// ────────────────────────────────────────────────────────────────────────────

/// Move `lines` lines in `direction` ("u" = up, "d" = down).
pub fn move_rel(buff: &mut Buffer, direction: &str, lines: i32) {
    if direction.starts_with('u') {
        // Go to BOL first, then move up.
        if buff.position != 1 {
            while left(buff, true) && buff.position != 1 {}
        }
        for _ in 0..lines {
            if buff.curr_line_idx == 0 {
                break;
            }
            up(buff);
        }
    } else {
        adv_line(buff);
        for i in 1..lines {
            if buff.curr_line_idx + 1 >= buff.lines.len() {
                break;
            }
            if i < lines {
                down(buff);
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
// next_page / prev_page
// ────────────────────────────────────────────────────────────────────────────

/// Move the cursor forward one page (mirrors C `next_page()`).
pub fn next_page(buff: &mut Buffer) {
    let last_line = buff.last_line;
    let mut counter = 0i32;
    while counter < last_line {
        if buff.curr_line_idx + 1 >= buff.lines.len() {
            break;
        }
        adv_line(buff);
        counter += 1;
    }
}

/// Move the cursor backward one page (mirrors C `prev_page()`).
pub fn prev_page(buff: &mut Buffer) {
    let last_line = buff.last_line;
    let mut counter = 0i32;
    while counter < last_line {
        if buff.curr_line_idx == 0 {
            break;
        }
        if buff.position != 1 {
            bol(buff);
        }
        bol(buff);
        counter += 1;
    }
}
